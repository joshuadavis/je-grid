package org.jgroups.service.lease;

public class LeaseException extends Exception {

    public LeaseException() {
        super();
    }

    public LeaseException(String s) {
        super(s);
    }
    
}